package com.wheelshare.util;

public enum Role {
	ADMIN,
	DRIVER,
	RIDER

}
