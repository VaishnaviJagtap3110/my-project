/*
 * package com.wheelshare.driver;
 * 
 * import org.springframework.cloud.openfeign.FeignClient;
 * 
 * @FeignClient(name = "dummy-service", url = "http://localhost:9999") public
 * interface DummyClient {
 * 
 * }
 */