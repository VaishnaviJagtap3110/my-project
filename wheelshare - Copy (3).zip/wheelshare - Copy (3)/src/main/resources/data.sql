INSERT INTO drivers (user_id, name, email, phone, status,banned,verified)
VALUES (
  1001,
  'Test Driver',
  'testdriver@wheelshare.com',
  '9999999999',
  'OFFLINE',
  false,
  false
);
INSERT INTO drivers (user_id, name, email, phone, status,banned,verified)
VALUES
(101, 'Rahul Sharma', 'rahul@gmail.com', '9876543210', 'OFFLINE',false,false),
(102, 'Anita Verma', 'anita@gmail.com', '9876501234', 'ONLINE',false,true),
(103, 'Vikas Patel', 'vikas@gmail.com', '9998887776', 'ON_RIDE',true,true);

