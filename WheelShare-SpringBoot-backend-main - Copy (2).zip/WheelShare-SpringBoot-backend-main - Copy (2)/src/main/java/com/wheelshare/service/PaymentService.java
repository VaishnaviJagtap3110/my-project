package com.wheelshare.service;

public class PaymentService implements PaymentServiceImpl {

}
