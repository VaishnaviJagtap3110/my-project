package com.wheelshare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WheelshareApplicationTests {

	@Test
	void contextLoads() {
	}

}
