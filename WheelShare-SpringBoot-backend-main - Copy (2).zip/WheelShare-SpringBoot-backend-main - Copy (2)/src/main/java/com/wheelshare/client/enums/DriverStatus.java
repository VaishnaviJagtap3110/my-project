package com.wheelshare.client.enums;

public enum DriverStatus {
	
		OFFLINE,
		ONLINE,
		ON_RIDE,
		SUSPENDED, BANNED


}
