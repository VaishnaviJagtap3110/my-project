package com.wheelshare.driver.dto;

public class DriverRequestDto {
	
	private String name;
	
	private String email;
	
	private String phone;

}
