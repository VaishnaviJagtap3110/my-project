package com.wheelshare.driver.util;

public enum DriverStatus {
	OFFLINE,
	ONLINE,
	ON_RIDE,
	 BANNED

}

