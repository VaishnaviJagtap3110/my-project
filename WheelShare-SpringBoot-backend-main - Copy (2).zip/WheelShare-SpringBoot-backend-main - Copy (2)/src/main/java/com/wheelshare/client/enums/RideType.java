package com.wheelshare.client.enums;

public enum RideType {
	 INDIVIDUAL,
	 SHARED,
	 POOL 

}
