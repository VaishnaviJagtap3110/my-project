package com.wheelshare.client.enums;

public enum RideShareRequestStatus {
	PENDING,
    ACCEPTED,
    REJECTED

}
