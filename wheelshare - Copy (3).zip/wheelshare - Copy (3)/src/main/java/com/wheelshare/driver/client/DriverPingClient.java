/*
 * package com.wheelshare.driver.client;
 * 
 * @FeignClient( name = "ride-service", url = http ) public interface
 * DriverPingClient {
 * 
 * @GetMapping("/ping") String pingRideService();
 * 
 * }
 */