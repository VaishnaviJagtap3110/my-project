package com.wheelshare.client.enums;

public enum RideStatus {
	REQUESTED,
    ACCEPTED,
    STARTED,
    COMPLETED,
    CANCELLED

}
