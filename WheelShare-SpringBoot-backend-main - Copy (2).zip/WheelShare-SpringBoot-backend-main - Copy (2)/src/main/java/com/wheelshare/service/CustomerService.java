package com.wheelshare.service;

import org.springframework.stereotype.Service;


public interface CustomerService  {

}
